# Security Policy

## Reporting a vulnerability
You can report low severity bugs at the [issues](https://github.com/qing762/exitlag-auto-signup/issues/new/) tab on this repository or join the [Discord server](https://qing762.is-a.dev/discord/) and create a ticket there.

However, for **higher severity vulnerabilities and bugs**, please do join the [Discord server](https://qing762.is-a.dev/discord/) and create a ticket there.