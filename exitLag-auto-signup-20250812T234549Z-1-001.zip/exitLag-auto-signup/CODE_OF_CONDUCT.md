# Code of Conduct
This is a Code of Conduct for any interactions in this repository. This includes pull requests, issues, etc.

- **No wrongful use** - Do not use this service as a way, to promote hacking, scams, fraud, and other illegal activites.

## Reporting abuse
If you believe a user using this service is abusing the terms, you can report it by creating an issue.

The abuse reports will be investigated and the necessary action will be taken.